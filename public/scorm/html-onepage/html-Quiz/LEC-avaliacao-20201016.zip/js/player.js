var finalizado = false;






$(document).ready(function(){
	
	loadPage();
} )

$( window ).unload(function() {
  unloadPage();
});